using System;
using System.Collections.Generic;
using System.Text;

namespace nagyszam
{
    class Program
    {

        private const int MAX = 100;

        static bool szam_e(char x)
        {
            if ((Convert.ToInt32(x) >= Convert.ToInt32('0')) && (Convert.ToInt32(x)<=Convert.ToInt32('9')))
                return true;
            return false;
        }

        static string beker(string duma)
        {
            bool meg;
            string sz;
            do
            {
                meg = false;
                Console.WriteLine("K�rem {0} sz�mot (max {1} jegy):",duma,MAX);
                sz = Console.ReadLine();
                if (sz.Length > MAX)
                {
                    Console.WriteLine("T�l nagy sz�m!");
                    meg = true;
                }
                for (int i = 0; i < sz.Length; i++)
                    if (!szam_e(sz[i]))
                    {
                        Console.WriteLine("Nem mind sz�mjegy!");
                        i = sz.Length;
                        meg = true;
                    }
            } while (meg);
            return sz;
        }

        static void Main(string[] args)
        {
            string sz1, sz2, st;
            int i,t,m;
            char[] ep = new char[MAX + 1];
            sz1 = beker("az els�");
            sz2 = beker("a m�sodik");
            st = "";
            for (i = sz1.Length; i <= MAX; i++)
                st += "0";
            sz1 = st + sz1;
            st = "";
            for (i = sz2.Length; i <= MAX; i++)
                st += "0";
            sz2 = st + sz2;
            m = 0;
            for (i = 0; i < MAX; i++)
            {
                t = Convert.ToInt32(sz1[MAX-i]) - Convert.ToInt32('0');
                t += Convert.ToInt32(sz2[MAX-i]) - Convert.ToInt32('0');
                t += m;
                if (t >= 10)
                {
                    m = 1;
                    t -= 10;
                }
                else
                    m = 0;
                ep [MAX-i] = Convert.ToChar(t+Convert.ToInt32('0'));
            }
            if (m == 1)
                ep[0] = '1';
            else
                ep[0] = '0';
            t = 0;
            while ((ep[t] == '0')&&(t<MAX))
                t++;
			Console.WriteLine("Az �sszeg:");
            for (i=t;i<=MAX;i++)
                Console.Write ("{0}",ep[i]);

            Console.ReadKey();
        }
    }
}
