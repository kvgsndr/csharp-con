﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace butagep
{
    class Program
    {
        static void Main(string[] args)
        {
            int i;
            double t;
            t = 1.0 / 3.0;
            Console.WriteLine(t);
            for (i = 1; i <= 30; i = i + 1)
            {
                t = t * 4 - 1;
                Console.WriteLine(t);
            }
            Console.ReadKey();
        }
    }
}
