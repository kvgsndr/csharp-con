﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace elerhetoseg
{
    class Program
    {
        static string[] nev = new string[1000];
        static int[] eid = new int[1000];
        static int edb = 0;
        static int[] elid = new int[1000];
        static char[] etip = new char[1000];
        static string[] adat = new string[1000];
        static int eldb = 0;

        static string nevkeres(int id)
        {//megkeresi az id-hez tartozó nevet
            for (int i = 0; i < edb; i++)
                if (eid[i] == id)
                    return nev[i];
            return "###HIBÁS ID###";
        }

        static void Main(string[] args)
        {
            //ember.txt nev;id
            //elerh.txt id;tipus;adat
            //tipus lehet M:mobil,V:vezetékes,A:állandó cím,I:ideiglenes cím,L:levelezési cím,E:e-mail,W:www

            string tar;

            //beolvasások
            StreamReader eolv = new StreamReader("ember.txt",Encoding.Default);
            while (!eolv.EndOfStream)
            {
                tar = eolv.ReadLine();
                string []s=tar.Split(';');
                nev[edb] = s[0];
                eid[edb] = Convert.ToInt32(s[1]);
                edb++;
            }
            eolv.Close();
            StreamReader olv = new StreamReader("elerh.txt", Encoding.Default);
            while (!olv.EndOfStream)
            {
                tar = olv.ReadLine();
                string[] s = tar.Split(';');
                elid[eldb] = Convert.ToInt32(s[0]);
                etip[eldb] = s[1][0];
                adat[eldb] = s[2];
                eldb++;
            }
            olv.Close();

            //mi kell?
            ConsoleKeyInfo ck;
            char t='@';
            do
            {
                Console.WriteLine("M:mobil, V:vezetékes, A:állandó, I:ideiglenes, L:levelezési, E:e-mail, W:www");
                ck = Console.ReadKey(true);
                t = Char.ToUpper(ck.KeyChar);
                if ((t != 'M') && (t != 'V') && (t != 'A') && (t != 'I') && (t != 'L') && (t != 'E') && (t != 'W'))
                        t = '@';
            } while (t == '@');
            Console.WriteLine("A kért lista:");
            //elsőre csak legyűjt
            for (int i=0;i<eldb;i++)
                if (etip[i] == t)
                {//ez egy keresett
                    tar = String.Format("{0}: {1}",nevkeres(elid[i]),adat[i]);
                    Console.WriteLine(tar);
                }
            Console.WriteLine("VÉGE");
            //csak az izgi kedvéért névsorba
            Console.WriteLine("A kért lista névsorban:");
            string[] nt = new string[1000];
            int db = 0;
            for (int i = 0; i < eldb; i++)
                if (etip[i] == t)
                {//ez egy keresett
                    nt[db] = String.Format("{0,-20}{1}", nevkeres(elid[i]), adat[i]);
                    db++;
                }
            //névsorba rakás
            for (int i=0;i<db-1;i++)
                for (int j=0;j<db-i-1;j++)
                    if (String.Compare(nt[j],nt[j+1])>0)
                    {
                        tar = nt[j];
                        nt[j] = nt[j + 1];
                        nt[j + 1] = tar;
                    }
            for (int i = 0; i < db; i++)
                Console.WriteLine(nt[i]);
            Console.WriteLine("VÉGE");
            Console.ReadKey();
        }
    }
}
