using System;
using System.Collections.Generic;
using System.Text;

namespace borton
{
    class Program
    {
        static void Main(string[] args)
        {
            string s;
            int n,i,koz;
            Console.Write("H�ny cella van? ");
            s = Console.ReadLine();
            n = Convert.ToInt32(s);
			bool[] b = new bool[n+1];
			for (i = 1; i <= n; i = i + 1)
            {
                b[i] = false;
            }
            for (koz = 1; koz <= n; koz++)//koz++    koz=koz+1
            {
                for (i = koz; i <= n; i = i + koz)
                {
                    b[i] = !b[i];
                }
                if (n < 70)
                {
                    for (i = 1; i <= n; i++)
                    {
                        if (b[i])
                            Console.Write("N");
                        else
                            Console.Write("Z");
                    }
                    Console.WriteLine("");
                }
            }
            Console.WriteLine("A kiengedhet� rabok:");
            for (i = 1; i <= n; i++)
            {
                if (b[i])
                {
                    Console.WriteLine("{0},",i);
                }
            }
			Console.WriteLine("Ismer�s ez a sz�msorozat?");
			Console.ReadKey();
        }
    }
}
