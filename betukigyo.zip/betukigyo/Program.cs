using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;


namespace betukigyo
{
    class Program
    {
        static void Main(string[] args)
        {
			Random rnd = new Random();
            Console.Title = "BET�K�GY�";
            char []kigyo = new char [80];
            int i,j,kdb;
            kdb = 0;
            ConsoleKeyInfo gomb = new ConsoleKeyInfo();
            Console.BackgroundColor=ConsoleColor.DarkCyan;
            Console.ForegroundColor = ConsoleColor.White;
            Console.Clear();
            Console.WriteLine("BET�K�GY�");
            do
            {
                kigyo[kdb] = Convert.ToChar(rnd.Next(Convert.ToInt32('A'),
                    Convert.ToInt32('Z') + 1));
                kdb++;
                Console.SetCursorPosition(0, 10);
                for (i = 0; i < kdb; i++)
                    Console.Write("{0}", kigyo[i]);
                for (i = kdb; i < 80; i++)
                    Console.Write(" ");
                Thread.Sleep(250);
                while (Console.KeyAvailable)
                {
                    gomb = Console.ReadKey(true);
                    for (i = 0; i < kdb; i++)
                    {
                        if (Char.ToUpper(gomb.KeyChar) == kigyo[i])
                        {
                            for (j = i; j < kdb - 1; j++)
                                kigyo[j] = kigyo[j + 1];
                            kdb--;
                            i--;
                        }
                    }
                }
            } while ((kdb < 80) && (kdb > 0) && (gomb.Key != ConsoleKey.Escape));
            Console.WriteLine();
            if (gomb.Key != ConsoleKey.Escape)
            {
                if (0 == kdb)
                    Console.Write("NYERT�L");
                else
                    Console.Write("NYERTEM");
                Console.WriteLine("\n\nEnterre kil�pek!");
                Console.ReadLine();
            }
        }
    }
}
