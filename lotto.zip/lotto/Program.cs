using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace lotto
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            sz�veg sor (a beolvasott sor)
            sz�veg t (ideiglenes t�rol�sra sz�vegk�nt)
            eg�sz p (hol tartunk egy sor feldolgoz�s�ban)
            eg�sz i (sz�ml�l�sra)
            eg�sz x (ideiglenes t�rol�sra)
            eg�sz t�mb szdb [91] (itt sz�moljuk, hogy melyik sz�mb�l mennyit h�ztak; 91, mert 0-t�l sz�mol)

            CIKLUS i = 1-90
                szdb[i] = 0;
            CV
            s olvas� nyit�sa a File-hoz
            AM�G nem �rt v�get s
                sor = s-b�l 1 sor
                sor = sor + " "
                p = 0
                CIKLUS i = 1-5 (soronk�nti 5 sz�m miatt)
                    t = "";
                    AM�G sor p. bet�je != ' '
                      t = t + sor p. bet�je
                      p = p + 1
                    CV
                    x = eg�ssz� alak�tva t ;
                    szdb[x] = szdb[x] + 1
                    p = p + 1
                CV
            CV
            s bez�r
            KI alapdum�k :)
            CIKLUS i = 1-90
                KI i,": ",szdb[i]
            CV
            v�r egy gomb lenyom�s�ra
            */
            string sor;
            string t;
            int p;
            int i;
            int x;
            int []szdb=new int[91];

            for (i = 1; i <= 90; i = i + 1)
            {
                szdb[i] = 0;
            }
            StreamReader r = new StreamReader("lottosz.dat");
            while (!r.EndOfStream)
            {
                sor = r.ReadLine ();
                sor = sor + " ";
                p = 0;
                for (i = 1; i <= 5; i = i + 1)
                {
                    t = "";
                    while (sor[p] != ' ')
                    {
                        t = t + sor[p];
                        p = p + 1;
                    }
                    x = Convert.ToInt32(t);
                    szdb[x] = szdb[x] + 1;
                    p = p + 1;
                }
            }
            r.Close();
            Console.WriteLine("A sz�mok h�z�si gyakoris�ga:");
            for (i = 1; i <= 90; i = i + 1)
            {
                Console.Write(i);
                Console.Write(": ");
                Console.WriteLine(szdb[i]);
            }
            Console.ReadKey();
        }
    }
}
