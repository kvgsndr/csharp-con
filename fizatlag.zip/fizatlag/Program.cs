﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace fizatlag
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            egész db (hány fizetés átlagát kell számolni)
            egész ossz (ide gyűlik a fizetések összege)
            szöveg sor (a beolvasott sor)
            szöveg t (ideiglenes tárolásra)
            egész p (hol tartunk egy sor feldolgozásában)
            
            KI alapdumák :)
            s olvasó nyitása a File-hoz
            db = 0 (még egy darab sincs)
            ossz = 0 (még nincs gyűjtött összeg)
            AMÍG nem ért véget s
                sor = s-ből 1 sor
                sor = sor + ';'
                p = 0 (a sor elején vagyunk)
                AMÍG sor p. betűje != ';'
                  p = p + 1
                CV
                p = p + 1 (a fizetés első betűjén vagyunk)
                t = ""
                AMÍG sor p. betűje != ';'
                  t = t + sor p. betűje
                  p = p + 1
                CV
                ossz = ossz + egésszé alakítva t
                db = db + 1
            CV
            s bezár
            KI ossz/db (vigyázni a típusra)
            vár egy gomb lenyomására
            */
            int db;
            int ossz;
            string sor;
            string t;
            int p;
            
            Console.WriteLine("Fizetések átlaga a fiz.txt file-ból");
            StreamReader s = new StreamReader ("fiz.txt");
            db = 0;
            ossz = 0;
            while (!s.EndOfStream)
            {
                sor = s.ReadLine();
				sor = sor + ";";
                p = 0;
                while (sor[p] != ';')
                {
                    p = p + 1;
                }
                p = p + 1;
                t = "";
                while (sor[p] != ';')
                {
                    t = t + sor[p];
                    p = p + 1;
                }
                ossz = ossz + Convert.ToInt32(t);
                db = db + 1;
            }
            s.Close();
            Console.Write("Az átlagfizetés: ");
            Console.WriteLine ((double)ossz/(double)db);
            Console.ReadKey();
        }
    }
}
