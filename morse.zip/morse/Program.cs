﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace morse
{
    class Program
    {
        struct madat
        {
            public char jel;
            public string szov;
            public string morse;
        }

        static void Main(string[] args)
        {
            string duma,aduma,morse;
            Console.WriteLine("MORSE program");
            ConsoleKeyInfo cki;
            do
            {
                Console.Write ("Mit alakítsak át:");
                duma = Console.ReadLine();
                aduma = "";
                for (int i=0;i<duma.Length;i++)
                {
                    switch (duma[i])
                    {
                        case 'á':
                        case 'Á':
                            aduma += 'A';
                            break;
                        case 'é':
                        case 'É':
                            aduma += 'E';
                            break;
                        case 'í':
                        case 'Í':
                            aduma += 'I';
                            break;
                        case 'ó':
                        case 'Ó':
                        case 'ő':
                        case 'Ő':
                        case 'ö':
                        case 'Ö':
                            aduma += 'O';
                            break;
                        case 'ú':
                        case 'Ú':
                        case 'ü':
                        case 'Ü':
                        case 'ű':
                        case 'Ű':
                            aduma += 'U';
                            break;
                        default:
                            if (Char.IsDigit(duma[i]))
                            {
                                aduma += duma[i];
                                break;
                            }
                            if (Char.IsLetter(duma[i]))
                            {
                                aduma += Char.ToUpper(duma[i]);
                                break;
                            }
                            if (duma[i] != ' ')
                                aduma += '@';
                            break;
                    }
                }
                Console.WriteLine ("Az átalakított:{0}",aduma);
                //ezt lehetne akár egy menetben is, de így didaktikusabb :)
                int mdb = 0;
                madat []mj = new madat[100];
                StreamReader o = new StreamReader("morse.txt", Encoding.Default);
                while (!o.EndOfStream)
                {
                    morse = o.ReadLine();
                    string[] s = morse.Split(',');
                    mj[mdb].jel = s[0][0];
                    mj[mdb].szov = s[1];
                    mj[mdb++].morse = s[2];
                }
                o.Close();
                morse = "";
                for (int i = 0; i < aduma.Length; i++)
                {
                    for (int p = 0; p < mdb; p++)
                        if (mj[p].jel == aduma[i])
                            morse += mj[p].morse;
                    morse += ' ';
                }
                Console.WriteLine("Morse-ul:{0}", morse);
                for (int i = 0; i < aduma.Length; i++)
                {
                    for (int p = 0; p < mdb; p++)
                        if (mj[p].jel == aduma[i])
                            Console.Write ("{0}; ",mj[p].szov);
                }
                Console.WriteLine("\n\nKilépés q, többi mégegyszer");
                cki = Console.ReadKey(true);
            } while (Char.ToUpper(cki.KeyChar) != 'Q');
        }
    }
}
