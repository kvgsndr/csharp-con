﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace gyumolcs
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            egész ossz (egy megye összesenjét gyűjti)
            egész moossz (Magyarország összesenjét gyűjti)
            egész p (hol tartunk egy sor feldolgozásában)
            egész i (számlálásra)
            szöveg sor (a beolvasott sor)
            szöveg t (ideiglenes tárolásra)

            KI alapdumák :)
            gy olvasó nyitása a file-hoz
            gy-ből 1 sor
            moossz = 0 (még nincs gyümölcs)
            AMÍG nem ért véget gy
                sor = ny-ből 1 sor
                sor = sor + "\t"
                p = 0 (sor elején tartunk)
                AMÍG sor p. betűje != '\t'
                  KI sor p. betűje
                  p = p + 1
                CV
                p = p + 1 (első gyümölcs első betűje)
                ossz = 0
                CIKLUS i = 1-7 (a 7 gyümölcs miatt)
                    t = ""
                    AMÍG sor p. betűje != '\t'
                      t = t + sor p. betűje
                      p = p + 1
                    CV
                    ossz = ossz + egésszé alakítva t
                    p = p + 1
                CV
                moossz = moossz + ossz (a nagy összesent is gyűjtjük)
                KI ossz
            CV
            gy bezár
            KI "Magyarország összesen: "
            KI moossz
            vár egy gomb lenyomására
            */
            int ossz;
            int moossz;
            int p;
            int i;
            string sor;
            string t;

            Console.WriteLine("Összesített gyümölcstermelés:");
            StreamReader gy = new StreamReader("gyumolcs.txt");
            gy.ReadLine();
            moossz = 0;
            while (!gy.EndOfStream)
            {
                sor = gy.ReadLine();
                sor = sor + "\t";
                p = 0;
                while (sor[p] != '\t')
                {
                    Console.Write(sor[p]);
                    p = p + 1;
                }
                p = p + 1;
                ossz = 0;
                for (i = 1; i <= 7; i = i + 1)
                {
                    t = "";
                    while (sor[p] != '\t')
                    {
                        t = t +sor[p];
                        p = p + 1;
                    }
                    ossz = ossz + Convert.ToInt32(t);
                    p = p + 1;
                }
                moossz = moossz + ossz;
                Console.Write(": ");
                Console.WriteLine(ossz);
            }
            gy.Close();
            Console.Write("Magyarország összesen: ");
            Console.WriteLine(moossz);
            Console.ReadKey();
        }
    }
}
