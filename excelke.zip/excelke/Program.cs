using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace excelke
{
    class Program
    {
        static void Main(string[] args)
        {
            string[,] e = new string[100, 100];
            int s,o,sm, om,p,pe;
            double te, se,tdb,sdb;
            double []oe=new double[100];
            double []odb=new double[100];
            string star, star2;
            // beolvas�s
            Console.WriteLine("KIS EXCEL\n");
            Console.WriteLine("Beolvas�s");
            StreamReader sr = File.OpenText("exceladat.txt");
            star = sr.ReadLine();
            p = 0;
            while (star[p] != '*')
                p++;
            star2 = star.Substring(0, p);
            sm = Convert.ToInt32(star2);
            p++;
            star2 = star.Substring(p);
            om = Convert.ToInt32(star2);
            for (s = 0; s < sm; s++)
            {
                star = sr.ReadLine() + ";";
                p = 0;
                for (o = 0; o < om; o++)
                {
                    if (p == star.Length)
                    {
                        e[s, o] = "#";
                    }
                    else
                    {
                        pe = p;
                        while (star[p] != ';')
                            p++;
                        if (p-pe==0)
                            e[s, o] = "#";
                        else
                            e[s, o] = star.Substring(pe, p - pe);
                    }
                    p++;
                }
            }
            sr.Close();
            // sz�m�t�s m�dja
            Console.WriteLine("Adatok beolvasva.");
            do
            {
                Console.Write("�sszeg 'o', �tlag 'a':");
                star = Console.ReadLine();
            } while ((star[0] != 'o') && (star[0] != 'a'));
            // sz�m�t�s
            te = tdb = 0;
            for (o = 0; o < om; o++)
                oe[o] = odb[o] = 0;
            for (s = 0; s < sm; s++)
            {
                se = sdb = 0;
                for (o = 0; o < om; o++)
                {
                    if (e[s, o] != "#")
                    {
                        Console.Write("{0}",e[s,o]);
                        se += Convert.ToDouble(e[s,o]);
                        sdb++;
                        te += Convert.ToDouble(e[s, o]);
                        tdb++;
                        oe[o] += Convert.ToDouble(e[s, o]);
                        odb[o]++;
                    }
                    Console.Write("\t");
                }
                if (star[0]=='a')
                    se /= sdb;
                Console.WriteLine("{0}", se);
            }
            for (o = 0; o < om; o++)
            {
                if (star[0] == 'a')
                    oe[o] /= odb[o];
                Console.Write("{0}\t", oe[o]);
            }
            if (star[0] == 'a')
                te /= tdb;
            Console.WriteLine("{0}", te);
            Console.ReadKey();
        }
    }
}
