﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace felvisk
{
    class Program
    {
        static void Main(string[] args)
        {//felvisk.txt alapján melyik iskolából kit vettek fel név\tdöntés\tiskola
            string tar;
            string []nev=new string[1000];
            string []isk=new string[1000];
            int db=0;
            //beolvasás
            StreamReader olv = new StreamReader("felvisk.txt",Encoding.Default);
            while (!olv.EndOfStream)
            {
                tar = olv.ReadLine();
                string[] s = tar.Split('\t');
                if ((s[1][0] == 'A') || (s[1][0] == 'N'))
                {//ő egy felvett
                    nev[db] = s[0];
                    isk[db] = s[2];
                    db++;
                }
            }
            olv.Close();
            //iskola és azon belül névsorba
            for (int i=0;i<db-1;i++)
                for (int j = 0; j < db - i - 1; j++)
                    if (String.Compare (isk[j]+nev[j],isk[j+1]+nev[j+1])>0)
                    {
                        tar = nev[j];
                        nev[j] = nev[j + 1];
                        nev[j + 1] = tar;
                        tar = isk[j];
                        isk[j] = isk[j + 1];
                        isk[j + 1] = tar;
                    }
            //kiíratás
            string utisk = "@";
            int idb = 0;
            int odb = 0;
            int iskdb = 0;
            for (int i = 0; i < db; i++)
            {
                if (String.Compare(utisk, isk[i]) != 0)
                {//új iskola
                    if (utisk[0] != '@')
                        Console.WriteLine("ÖSSZESEN: {0}\n",idb);
                    Console.WriteLine("{0}",isk[i]);
                    utisk = isk[i];
                    idb = 0;
                    iskdb++;
                }
                Console.WriteLine("    {0}",nev[i]);
                idb++;
                odb++;
            }
            Console.WriteLine("ÖSSZESEN: {0}\n", idb);
            Console.WriteLine("VÉGE MINDÖSSZESEN {0} gyermek {1} iskolából; átlagosan {2:N2}",odb,iskdb,(double)odb/iskdb);
            Console.ReadKey();
        }
    }
}
