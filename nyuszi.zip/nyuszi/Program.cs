using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace nyuszi
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            eg�sz tojas (darabsz�m sz�mol�s�ra)
            eg�sz csoki (darabsz�m sz�mol�s�ra)
            eg�sz suti (darabsz�m sz�mol�s�ra)
            sz�veg tar (a beolvasott sor)

            tojas = 0
            csoki = 0
            suti = 0
            KI alapdum�k :)
            ny olvas� nyit�sa a File-hoz
            AM�G nem �rt v�get s
                tar = ny-b�l 1 sor
                KI tar
                tar = ny-b�l 1 sor
                tojas = tojas + eg�ssz� alak�tva tar
                tar = ny-b�l 1 sor
                csoki = csoki + eg�ssz� alak�tva tar
                tar = ny-b�l 1 sor
                suti = suti + eg�ssz� alak�tva tar
            CV
            ny bez�r
            KI tojas,csoki,suti sz�p dum�kkal :)
            v�r egy gomb lenyom�s�ra
            */
            int tojas;
            int csoki;
            int suti;
            string tar;

            tojas = 0;
            csoki = 0;
            suti = 0;
            Console.WriteLine("A locsol�s eredm�nye:");
            StreamReader ny = new StreamReader("nyuszi.txt");
            while (!ny.EndOfStream)
            {
                tar = ny.ReadLine();
                Console.WriteLine(tar);
                tar = ny.ReadLine();
                tojas = tojas + Convert.ToInt32(tar);
                tar = ny.ReadLine();
                csoki = csoki + Convert.ToInt32(tar);
                tar = ny.ReadLine();
                suti = suti + Convert.ToInt32(tar);
            }
            ny.Close();
            Console.Write("�sszesen: ");
            Console.Write(tojas);
            Console.Write(" toj�st, ");
            Console.Write(csoki);
            Console.Write(" csokit �s ");
            Console.Write(suti);
            Console.Write(" s�tit kaptam.");
            Console.ReadKey();
        }
    }
}
