using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Threading;

namespace eletj
{
    class Program
    {
        static void Main(string[] args)
        {
            char[,] t = new char[81, 27]; //0-80,0-26 val�di t�r 1-79,1-25
            int x,y; // t�bla (t) koordin�t�i
            int szsz,szszN,szszK; // szomsz�dsz�mok
            int dx, dy; // elt�r�s  x,y-t�l
            char c;
            string s;
            char csapat; // beolvas�sn�l melyik csapatn�l vagyok
            // t�blat�rl�s
            for (x = 0; x < 81; x++)
                for (y = 0; y < 27; y++)
                    t[x, y] = ' ';
            // els� csapat a nagybet�s
            csapat = 'X';
            // beolvas�s
            StreamReader o = File.OpenText("eletalap.txt");
            while (!o.EndOfStream)
            {
                s = o.ReadLine();
                if ("2.cs" == s)
                {
                    s = o.ReadLine();
                    csapat = 'x';
                }
                x = Convert.ToInt32(s);
                y = Convert.ToInt32(o.ReadLine());
                t[x, y] = csapat;
            }
            o.Close();
            // �LETCIKLUS
            c = 'g';
            do
            {
                // ki�rat�s
                Console.Clear();
                for (y = 1; y < 26; y++)
                {
                    for (x = 1; x < 80; x++)
                    {
                        switch (t[x, y])
                        {
                        case 'X':
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.Write("X");
                            break;
                        case 'x':
                            Console.ForegroundColor = ConsoleColor.Blue;
                            Console.Write("X");
                            break;
                        case ' ':
                            Console.Write(" ");
                            break;
                        }
                    }
                    if (y!=25)
                        Console.Write(' ');
                }
                // v�rakoz�s
                Thread.Sleep(500);
                // sz�let�s, hal�loz�s
                for (x=1;x<80;x++)
                    for (y=1;y<26;y++)
                    {
                        // 1. A sejt t�l�li a k�rt, ha k�t vagy h�rom szomsz�dja van.
                        // 2. A sejt elpusztul, ha kett�n�l kevesebb (elszigetel�d�s), vagy h�romn�l t�bb (t�ln�pesed�s) szomsz�dja van.
                        // 3. �j sejt sz�letik minden olyan cell�ban, melynek k�rnyezet�ben pontosan h�rom sejt tal�lhat�.
                        // sz�k�z=nincs; X=van; P=pusztul; S=sz�letik
                        // szomsz�dsz�m sz�mol�s
                        szszN = szszK = 0;
                        for (dx=x-1;dx<=x+1;dx++)
                            for (dy = y - 1; dy <= y + 1; dy++)
                            {
                                if ((t[dx, dy] == 'X') || (t[dx, dy] == 'P'))
                                    szszN++;
                                if ((t[dx, dy] == 'x') || (t[dx, dy] == 'p'))
                                    szszK++;
                            }
                        switch (t[x, y])
                        {
                        case 'X':
                            szsz = szszK + szszN - 1;
                            if ((szsz<2)||(szsz>3))
                                t[x,y]='P';
                            break;
                        case 'x':
                            szsz = szszK + szszN - 1;
                            if ((szsz<2)||(szsz>3))
                                t[x,y]='p';
                            break;
                        case ' ':
                            szsz = szszK + szszN;
                            if (szsz == 3)
                                if (szszN > szszK)
                                    t[x, y] = 'S';
                                else
                                    t[x, y] = 's';
                            break;
                        }
                    }
                // P �s S kicser�l�se
                for (x=1;x<80;x++)
                    for (y=1;y<26;y++)
                    {
                        if (t[x, y] == 'P')
                            t[x, y] = ' ';
                        if (t[x, y] == 'p')
                            t[x, y] = ' ';
                        if (t[x, y] == 'S')
                            t[x, y] = 'X';
                        if (t[x, y] == 's')
                            t[x, y] = 'x';
                    }
                // kil�p�s?
                if (Console.KeyAvailable)
                    c= Console.ReadKey().KeyChar;
            } while (c!='Q');
        }
    }
}
