﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace maxfiz
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            egész max (az idáig talált legnagyobb fizetés)
            szöveg maxnev (a legnagyobb fizetést kapó neve)
            szöveg sor (a beolvasott sor)
            szöveg t (az aktuális fizetés tárolásra szövegként)
            szöveg nt (az aktuális név tárolásra)
            egész f (az aktuális fizetés tárolására)
            egész p (hol tartunk egy sor feldolgozásában)
            
            KI alapdumák :)
            s olvasó nyitása a File-hoz
            max = 0 (ennél csak nagfyobb lesz)
            maxnev = ""
            AMÍG nem ért véget s
                sor = s-ből 1 sor
                p = 0 (a sor elején vagyunk)
                nt = ""
                AMÍG sor p. betűje != ';'
                  nt = nt + sor p. betűje
                  p = p + 1
                CV
                p = p + 1 (a fizetés első betűjén vagyunk)
                t = ""
                AMÍG sor p. betűje != ';'
                  t = t + sor p. betűje
                  p = p + 1
                CV
                f = egésszé alakítva t
                Ha max < f AKKOR
                    max = f
                    maxnev = nt
                EV
                db = db + 1
            CV
            s bezár
            KI maxnev, max
            vár egy gomb lenyomására
            */
            int max;
            string maxnev;
            string sor;
            string t;
            string nt;
            int f;
            int p;

            Console.WriteLine("Legnagyobb fizetés fiz.txt file-ból");
            StreamReader s = new StreamReader("fiz.txt");
            max = 0;
            maxnev = "";
            while (!s.EndOfStream)
            {
                sor = s.ReadLine();
                sor = sor + ";";
                p = 0;
                nt = "";
                while (sor[p] != ';')
                {
                    nt = nt + sor[p];
                    p = p + 1;
                }
                p = p + 1;
                t = "";
                while (sor[p] != ';')
                {
                    t = t + sor[p];
                    p = p + 1;
                }
                f = Convert.ToInt32(t);
                if (max < f)
                {
                    max = f;
                    maxnev = nt;
                }
            }
            s.Close();
            Console.Write("A Legtöbbet kereső: ");
            Console.Write(maxnev);
            Console.Write(": ");
            Console.WriteLine(max);
            Console.ReadKey();
        }
    }
}
