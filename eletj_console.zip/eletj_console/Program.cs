﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace eletj_console
{
    class Program
    {
        static void Main(string[] args)
        {
            string fn;
            int szdb;
            char[,] st = new char[82, 26];
            char[,] t = new char[82, 26];
            for (int x = 0; x < 82; x++)
                for (int y = 0; y < 26; y++)
                    t[x, y] = ' ';
            Console.Write("Kérem a kiindulási file nevét:");
            fn = Console.ReadLine();
            StreamReader o = new StreamReader(fn);
            while (!o.EndOfStream)
            {
                fn = o.ReadLine();
                string[] s = fn.Split(',');
                t[Convert.ToInt32(s[0]), Convert.ToInt32(s[1])] = 'O';
            }
            o.Close();
            ConsoleKeyInfo ci;
            do
            {
                Console.Clear();
                for (int y=1;y<=24;y++)
                    for (int x = 1; x <= 80; x++)
                        Console.Write(t[x, y]);
                ci = Console.ReadKey(true);
                for (int y = 1; y <= 24; y++)
                    for (int x = 1; x <= 80; x++)
                    {
                        szdb = 0;
                        for (int dx = x - 1; dx <= x + 1;dx++)
                            for (int dy = y - 1; dy <= y + 1; dy++)
                                if (t[dx, dy] == 'O')
                                    szdb++;
                        if (t[x, y] == 'O')
                            if ((szdb == 3) || (szdb == 4))
                                st[x, y] = 'O';
                            else
                                st[x, y] = ' ';
                        else
                            if (szdb == 3)
                                st[x, y] = 'O';
                            else
                                st[x, y] = ' ';
                    }
                for (int y = 1; y <= 24; y++)
                    for (int x = 1; x <= 80; x++)
                        t[x, y] = st[x, y];
            } while (ci.KeyChar != 'q');
        }
    }
}
